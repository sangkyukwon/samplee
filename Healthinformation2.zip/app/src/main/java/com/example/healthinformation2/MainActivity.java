package com.example.healthinformation2;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.healthinformation2.R;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

   GridView gridView;


    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);


        gridView = (GridView) this.findViewById(R.id.gridview);

        ArrayList<String> items = new ArrayList<>();

        items.add("정보1");
        items.add("정보2");
        items.add("정보3");
        items.add("정보4");
        items.add("정보5");
        items.add("정보6");
        items.add("정보7");
        items.add("정보8");

        CustomAdapter adapter = new CustomAdapter(this, 0, items);
        gridView.setAdapter(adapter);
    }

    private class CustomAdapter extends ArrayAdapter<String> {
        private ArrayList<String> items;

        public CustomAdapter(Context context, int textViewResourceId, ArrayList<String> objects) {
            super(context, textViewResourceId, objects);
            this.items = objects;
        }

        public View getView(int position, View convertView, ViewGroup parent) {
            View v = convertView;
            if (v == null) {
                LayoutInflater vi = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                v = vi.inflate(R.layout.listviewitem, null);
            }

            ImageView imageView = (ImageView)v.findViewById(R.id.imageView);

           /* if("정보1".equals(items.get(position)))
                imageView.setImageResource(R.drawable.정보이미지1);
            else if("정보2".equals(items.get(position)))
                imageView.setImageResource(R.drawable.정보이미지2);
            else if("정보3".equals(items.get(position)))
                imageView.setImageResource(R.drawable.정보이미지3);
            else if("정보4".equals(items.get(position)))
                imageView.setImageResource(R.drawable.정보이미지4);*/


            TextView textView = (TextView)v.findViewById(R.id.textView);
            textView.setText(items.get(position));

            final String text = items.get(position);


            imageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(
                            getApplicationContext(),
                            information_M.class);
                    startActivity(intent);

                }
            });

            return v;
        }
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }


}
